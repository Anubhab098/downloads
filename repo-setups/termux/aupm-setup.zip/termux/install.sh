#AUPM PACKET MANAGER INSTALLATING SCRIPT


mkdir $HOME/tmp

mv aupm /data/data/com.termux/files/usr/bin/
mv aupm-clean /data/data/com.termux/files/usr/bin/

cd /data/data/com.termux/files/usr/bin/

chmod +x aupm
chmod +x aupm-clean


echo "All Done"

 
echo "Now You Can Use Aupm-packet manager with command called aupm"
