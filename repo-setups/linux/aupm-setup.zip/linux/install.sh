#AUPM PACKET MANAGER INSTALLATING SCRIPT


mkdir $HOME/tmp

mv aupm /bin
mv aupm-clean /bin

cd /bin

chmod +x aupm
chmod +x aupm-clean



echo "All Done"

 
echo "Now You Can Use Aupm-packet manager with command called aupm";



